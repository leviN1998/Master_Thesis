#!/bin/bash

# Prüfe, ob ein Pfad übergeben wurde
if [ -z "$1" ]; then
  echo "Verwendung: $0 /pfad/zum/ordner"
  exit 1
fi

FOLDER="$1"

# Prüfe, ob der Ordner existiert
if [ ! -d "$FOLDER" ]; then
  echo "Fehler: '$FOLDER' ist kein gültiger Ordner."
  exit 1
fi

# Durchlaufe alle passenden PNG-Dateien
for file in "$FOLDER"/*_*_*.png; do
  [ -e "$file" ] || continue  # Überspringe, wenn keine passenden Dateien

  # Extrahiere Dateiname ohne Pfad
  base=$(basename "$file")

  # Extrahiere den ersten Teil vor dem ersten Unterstrich
  prefix="${base%%_*}"

  # Schneide die letzten 10 Stellen der Zahl
  short_prefix="${prefix: -12}"

  # Neuer Dateiname mit Pfad
  new_name="${FOLDER}/${short_prefix}.png"

  # Umbenennen
  mv "$file" "$new_name"
  echo "Umbenannt: $base → ${short_prefix}.png"
done
